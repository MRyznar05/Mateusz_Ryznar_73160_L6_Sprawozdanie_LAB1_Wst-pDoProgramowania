uczelnia = str("Studiuję na WSIiZ")
print(uczelnia)