cena = 39.99
rabat = 0.2
cena_rabatowa = cena-(cena*rabat)
print(str(round(cena_rabatowa, 2)),"PLN")