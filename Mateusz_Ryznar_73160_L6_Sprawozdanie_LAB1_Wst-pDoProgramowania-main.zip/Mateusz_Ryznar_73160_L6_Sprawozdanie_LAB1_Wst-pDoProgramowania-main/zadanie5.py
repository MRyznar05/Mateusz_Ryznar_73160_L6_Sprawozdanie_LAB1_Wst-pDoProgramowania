a = int(input("Podaj bok prostokąta: "))
b = int(input("Podaj drugi bok prostokąta: "))
pole = a*b
obwod = ((2*a)+(2*b))
print("Pole jest równe: ", pole)
print("Obwód jest równy: ", obwod)