imie = "Jan"
wiek = 20
wzrost = 178

print("Nazywam się", imie, "i mam", wiek, "lat.", "\n","Mój wzrost to", wzrost, "cm." )